# Software Bug Severity Prediction from Bug Reports

Compares Multinomial Naive Bayes, Logistic Regression and Linear SVM (scikit-learn, TF-IDF features)
at predicting High Severity vs Routine from a bug report description. CPU only, no GPU needed.

## Dataset
Eclipse Bugzilla bug reports, Hugging Face: https://huggingface.co/datasets/AndressaStefany/bug-reports
Download `my_dataset.csv` (columns: _id, bug_id, description, bug_severity, bug_status, resolution)
and put it next to the notebook (or upload it to the Colab Files panel).
The Zenodo Eclipse dataset (DOI 10.5281/zenodo.15348468) was inspected but not used: its sample file has
only 100 rows (9 High Severity after filtering) and the full archive is 17.2 GB.

## Run
1. `pip install -r requirements.txt` (or use Google Colab, which already has these packages).
2. Open `Bug_Severity_Prediction.ipynb` and run all cells top to bottom. The grid searches take a few minutes each on CPU.
3. One cell imports `google.colab` to download a file; skip it when running locally.
4. Demo: set `demo_case` in the prediction cell to the JVM or EMF report, run it, then run the next cell to reveal the recorded label.

## Files
- `Bug_Severity_Prediction.ipynb`: full notebook with outputs from our run
- `all_model_results.csv`, `tuned_test_results.csv`: scores on the 10,080-report test set
- `*.png`: EDA, model comparison, confusion matrix and precision-recall curves, term weights
- `requirements.txt`: package versions used in the Colab session

## Method in brief
Stratified 80/20 split (seed 42); TF-IDF fitted on training data only (20,000 features, 1-2 word phrases, min_df=3);
tuned models use 5-fold CV for hyperparameters and a validation split for the decision threshold; test set used for final scoring.
